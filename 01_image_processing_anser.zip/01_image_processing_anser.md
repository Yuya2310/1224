
# 画像処理の基礎（問題）

画像を用いて機械学習などを行う場合、モデルを学習するための前処理として様々な加工を行う必要があります。  
ここでは、必要最低限な7つの基本処理を問題として用意しています。  

1. チャネル入れ替え
2. グレースケール化
3. 二値化
4. アルファチャンネルの操作
5. ガウシアンフィルタ
6. ヒストグラム表示
7. アフィン変換

これらの処理はOpenCVを用いて実行可能ですが、画像処理の理解を深めるために処理内容を実装する問題形式としています。  
「□」部分のスクリプトを埋めていき、処理内容を実装してください。    

OpenCVを使った画像処理については以下をご参照ください。  
http://labs.eecs.tottori-u.ac.jp/sd/Member/oyamada/OpenCV/html/py_tutorials/py_imgproc/py_table_of_contents_imgproc/py_table_of_contents_imgproc.html

<br>

## はじめに
以下のコードを実行し、画像処理で利用するPythonのライブラリを読み込みましょう。


```python
# 画像処理ライブラリの読み込み
import cv2
import numpy as np
import matplotlib.pyplot as plt

# JupyterNotebook上に画像やグラフを描画する際に指定する記述
%matplotlib inline 

# jupyter notebook上でグレースケール表示する場合に使用するおまじない
plt.gray()
```


    <Figure size 432x288 with 0 Axes>


<br>

## 1. チャネル入れ替え
`cv2.imread()`関数では、チャネルがBGRの順に読み込まれます。  
画像（hinemos_monita.jpg）を読み込み、BGRをRGBの順に入れ替えてみましょう。

チャネル入れ替え前後の画像は以下のとおりです。  
<img src="./pic/before_after_chanel.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
img = cv2.imread("./pic/hinemos_monita.jpg")
```


```python
# imgのサイズを確認　
print(img.shape) # 【参考】を確認
```

    (400, 400, 3)
    

【参考】  
OpenCVで読み込まれた画像ファイル（img）はNumPy配列ndarrayとして扱われ、  
ndarrayの形状を示す属性shapeから画像のサイズ（高さ×幅×チャネル数）を取得できます。  
また、BGRで読込まれた画像の各チャネルの画素値は以下のコードで取得できます。 

・チャネルBの画素値：`img[:, :, 0]`  
・チャネルGの画素値：`img[:, :, 1]`  
・チャネルRの画素値：`img[:, :, 2]`  


```python
# 元画像imgを表示
plt.imshow(img)
plt.show()
```


![png](output_11_0.png)



```python
# 【回答】BGR→RGBに変換する関数（BGR2RGB）を定義

def BGR2RGB(img):

    # 各チャネルの画素値をcopy()関数で変数b,g,rにコピーする
    b = img[:, :, 0].copy() #チャネルBの画素値をbに格納
    g = img[:, :, 1].copy() #チャネルGの画素値をgに格納
    r = img[:, :, 2].copy() #チャネルRの画素値をrに格納

    # imgの各チャネルをb,g,rで置き換える（BGR →RGB）
    img[:, :, 0] = r #チャネルBの画素値をrで置換える
    img[:, :, 1] = g #チャネルGの画素値はgのまま
    img[:, :, 2] = b #チャネルRの画素値をbで置換える

    return img
```


```python
# BGR2RGB()関数を用いてRGB変換した画像を表示　
img_rgb = BGR2RGB(img)
plt.imshow(img_rgb)
plt.show()
```


![png](output_13_0.png)



```python
#【参考】OpenCVを使う場合

img = cv2.imread("./pic/hinemos_monita.jpg")

img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

plt.imshow(img)
plt.show()
```


![png](output_14_0.png)


## 2. グレースケール化
画像（hinemos_monita.jpg）をグレースケールにしてみましょう。  
グレースケールとは、画像の輝度表現方法の一種であり、下式で計算されます。  
$$
Y = 0.2126 R + 0.7152 G + 0.0722 B
$$
  
グレースケール化の輝度表現方法については以下をご参照ください。  
https://qiita.com/yoya/items/96c36b069e74398796f3

グレースケール化前後の画像は以下の通りです。  
<img src="./pic/before_after_grey.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
img = cv2.imread("./pic/hinemos_monita.jpg")
```


```python
# 【回答】グレースケール化処理を行う関数（BGR2GRAY）を定義

def BGR2GRAY(img):

    # 各チャネルの画素値をcopy()関数で変数b,g,rにコピーする
    b = img[:, :, 0].copy() # チャネルBの画素値をbに格納
    g = img[:, :, 1].copy() # チャネルGの画素値をgに格納
    r = img[:, :, 2].copy() # チャネルRの画素値をrに格納

    # グレースケールに変換
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b  # 画素値を輝度表現の式に当てはめる
    y = y.astype(np.uint8) # folat型からint型に変換（【参考】を確認）

    return y
```


```python
plt.imshow(img)
plt.show()
```


![png](output_19_0.png)


【参考】  
    画像の輝度を変更することで画素値がfloat型に変換されます。  
    float型で画像を表示すると表示形式が崩れるため、int型に変更する必要があります。  
    型の変更には`astype()`を用いて処理できます。


```python
#BGR2GRAY()関数を用いてグレースケール化した画像を表示　
gray = BGR2GRAY(img)
plt.imshow(gray)
plt.show()
```


![png](output_21_0.png)



```python
#【参考】OpenCVを使う場合

img = cv2.imread("./pic/hinemos_monita.jpg")

img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

plt.imshow(img)
plt.show()
```


![png](output_22_0.png)


<br>

## 3. 二値化
画像（hinemos_monita.jpg）を二値化してみましょう。  
二値化とは、画像を黒と白の二値で表現する方法です。  
ここでは、グレースケールにおいて閾値を128に設定し、下式で二値化させましょう。  
$$
y =
    \begin{cases}
        0 \quad y < 128 \\
        255 \quad y \geqq 128 \\
    \end{cases}
$$

二値化前後の画像は以下のとおりです。  
<img src="./pic/before_after_binari.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
img = cv2.imread("./pic/hinemos_monita.jpg")
```


```python
# 【回答】二値化処理を行う関数（binarization）を定義

def binarization(img, th=128):
    
    # imgの画素値を閾値thを条件に変換する
    img[img < th] = 0   # 画素値が閾値thより小さいものは黒（0）に変換
    img[img >= th] = 255  # 画素値が閾値th以上のものは白（255）に変換
    
    return img
```


```python
# BGR2GRAY()、binarization()関数を用いて二値化した画像を表示　
gray = BGR2GRAY(img) # 2.グレースケール化で定義した関数を利用
out = binarization(gray)
plt.imshow(out)
plt.show()
```


![png](output_28_0.png)



```python
# 【参考】OpenCVを使う場合

img = cv2.imread("./pic/hinemos_monita.jpg")

# グレースケール化
img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)

# 閾値の設定
threshold = 100

# 二値化(閾値100を超えた画素を255にする
ret, img_thresh = cv2.threshold(img, threshold, 255, cv2.THRESH_BINARY)

plt.imshow(img_thresh)
plt.show()
```


![png](output_29_0.png)


<br>

## 4. アルファチャンネルの操作　
アルファチャンネルとは、画像処理分野においては一般に画素の不透明度 (opacity) を表現します。  
このアルファチャンネルによって「画像のどの部分をどのくらい透明にするか」を表現できます。  
アルファチャンネルがある画像はチャネル数が（B,G,R,a）の4次元となります。  
そのため、OpenCVで画像を読み込むときには、オプション`cv2.IMREAD_UNCHANGED`を指定する必要があります。  
透過処理されている画像を、`cv2.IMREAD_UNCHANGED`を指定しないで読込んだ場合、背景色が黒に表示されることがあります。  

透過処理前後の画像は以下のとおりです。  
<img src="./pic/before_after_touka.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
img_alf = cv2.imread("./pic/hinemos_monita-a.png",cv2.IMREAD_UNCHANGED)
```


```python
# 次元数が4次元（B,G,R,α）であることを確認
img_alf.shape
```




    (322, 272, 4)



`img_alf.shape`の出力結果は（高さ：322,幅：272,チャネル数：4）となっており、  
このチャネル数が4次元（B,G,R,α）であることが確認できます。


```python
# 元画像を表示
plt.imshow(img_alf)
plt.show()
```


![png](output_36_0.png)


透過処理されている画像をRGB画像として読み込むと背景色が黒で表示されることがあります。


```python
img_alf2 = cv2.imread("./pic/hinemos_monita-a.png")
plt.imshow(img_alf2)
plt.show()
```


![png](output_38_0.png)


Deep Learningへの入力とする際は、アルファチャンネルは使用しない場合が多いため、背景部分は黒→白に変換した上で使用します。  
背景色の変換には`numpy.where()`を使用し、条件に当てはまるピクセルの画素値を変換することで処理できます。


```python
# 【回答】アルファチャンネルを除去し、背景色を黒から白に変換する関数（remove_alf）を定義

def remove_alf(img):
    
    # アルファチャンネルを除去（BGRの画素値のみを取得）
    img = img[:,:,0:3]
    
    # 各チャネルごとに画素値を0→255変換
    img[:, :, 0] = np.where(img[:, :, 0]==0,img[:, :, 0]+255,img[:, :, 0]) # チャネルBの画素値0を255に変換
    img[:, :, 1] = np.where(img[:, :, 1]==0,img[:, :, 1]+255,img[:, :, 1]) # チャネルGの画素値0を255に変換
    img[:, :, 2] = np.where(img[:, :, 2]==0,img[:, :, 2]+255,img[:, :, 2]) # チャネルRの画素値0を255に変換
    
    return img
```


```python
# remove_alf()関数を用いて背景色を黒→白に変換した画像を表示　
img = remove_alf(img_alf)
plt.imshow(img)
plt.show()
```


![png](output_41_0.png)



```python
# アルファチャンネルが除去されているか確認
img.shape
```




    (322, 272, 3)



<br>

## 5. ガウシアンフィルタ
ガウシアンフィルタ(3x3、標準偏差1.3)を実装し、画像（white_rabbit.jpeg）のノイズを除去してみましょう。  
  
ガウシアンフィルタとは画像の平滑化（滑らかにする）を行うフィルタの一種であり、ノイズ除去にも使われます。  
ノイズ除去には他にも、メディアンフィルタ、平滑化フィルタ、LoGフィルタなどがあります。 
  
ガウシアンフィルタの詳細な説明については以下をご参照ください。  
http://optie.hatenablog.com/entry/2018/03/21/185647

ノイズ除去前後の画像は以下の通りです。  
<img src="./pic/before_after_noizu.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
img = cv2.imread("./pic/white_rabbit.jpeg")

# 元画像を表示
plt.imshow(img)
plt.show()
```


![png](output_46_0.png)



```python
# 【回答】画像にガウシアンフィルタを行う関数（gaussian_filter）を定義せよ
def gaussian_filter(img, K_size=3, sigma=1.3):
    
    # K_size:カーネル（大きいほどぼかしの具合が強くなる）
    # sigma:標準偏差（同じく大きくするとぼかしの具合が強くなる）
    
    
    # 縦、横の長さとチャネル数を取得
    if len(img.shape) == 3:
        H, W, C = img.shape
    else:
        img = np.expand_dims(img, axis=-1)
        H, W, C = img.shape

        
    # Zero padding
    pad = K_size // 2 # カーネルサイズを2で整数除算
    
    # 元画像の端を0で埋めるためパディングサイズ分大きい0埋めの画像を作成
    out = np.zeros((H + pad * 2, W + pad * 2, C), dtype=np.float)
    
    # 元画像をコピー ※画像の端には貼り付けない
    out[pad: pad + H, pad: pad + W] = img.copy().astype(np.float)

    
    # prepare Kernel
    # (縦：カーネルサイズ,横：カーネルサイズ)の空の行列を作成
    K = np.zeros((K_size, K_size), dtype=np.float)
    
    # ガウシアンフィルタのためのカーネル行列を作成
    for x in range(-pad, -pad + K_size):
        for y in range(-pad, -pad + K_size):
            K[y + pad, x + pad] = np.exp( -(x ** 2 + y ** 2) / (2 * (sigma ** 2)))
    
    K /= (2 * np.pi * sigma * sigma)
    K /= K.sum()

    tmp = out.copy()

    # filtering
    for y in range(H):
        for x in range(W):
            for c in range(C):
                out[pad + y, pad + x, c] = np.sum(K * tmp[y: y + K_size, x: x + K_size, c])

    out = np.clip(out, 0, 255)
    out = out[pad: pad + H, pad: pad + W].astype(np.uint8)

    return out
```


```python
# ガウシアンフィルタをかけた画像を表示
gaus = gaussian_filter(img, K_size=3, sigma=1.3)
plt.imshow(gaus)
plt.show()
```


![png](output_48_0.png)



```python
#【参考】OpenCVでのガウシアンフィルタのかけかた

img = cv2.imread("./pic/white_rabbit.jpeg")

img = cv2.GaussianBlur(img, ksize=(5, 5), sigmaX=1.3)

plt.imshow(img)
plt.show()
```


![png](output_49_0.png)


<br>

## 6. ヒストグラム表示
matplotlibを用いて画像（white_rabbit.jpeg）のヒストグラムを表示してみましょう。  
ヒストグラムとは画素の輝度値ごとの出現回数をグラフにしたものです。  
画素の輝度値の分布を確認することで、  
明るさや色の補正、コントラストの強調などの画像処理を行うときの参考とすることができます。  
また、２値化処理により画像の一部の切り出しを行う際の、閾値の決定にも用いられます。  


```python
# 画像の読み込み
img = cv2.imread("./pic/white_rabbit.jpeg")
```


```python
# 【回答】white_rabbit.jpegの画素値の輝度ごとのヒストグラムを表示せよ 
plt.hist(img.flatten(), bins=255, rwidth=0.8, range=(0, 255))
plt.show()
```


![png](output_53_0.png)


【参考】   
以下の引数を設定することで、ヒストグラムを表示を調整できます。  
`plt.hist(img, bins=X, rwidth=X, range=(X,X))`   
- img: 読込んだ画像（第一引数は一次元配列である必要があるため、多次元の場合はflatten()を用いて一次元化する必要がある）
- bins:ビン (表示する棒) の数。階級数。(デフォルト値: 10)　  
- rwidth:各棒の幅を数値または、配列で指定。  
- range:ビンの最小値と最大値を指定。(デフォルト値: (x.min(), x.max()))

その他にも様々なパラメータを設定することでヒストグラムの表示を調整することができます。  
https://pythondatascience.plavox.info/matplotlib/%E3%83%92%E3%82%B9%E3%83%88%E3%82%B0%E3%83%A9%E3%83%A0

<br>

## 7. アフィン変換　
Deep Learningを用いて精度の良いモデルを作成するには、大量の学習データが必要となります。  
しかし、実社会では十分な量の学習データを揃えることができないケースが多々あります。  
そこで、少ないデータで学習するテクニックの一つとして、学習データの水増し（データ拡張）があります。  
学習データの水増しとは、元の学習データに変換を加えてデータ量を増やすテクニックで、  
特にCNN（畳み込みニューラルネットワーク）などを使った画像処理で効果を発揮します。  
ここでは、画像変換方法としてアフィン変換を紹介します。

アフィン変換とは、３×３の行列を使って変換する処理です。  
詳細な説明については以下をご参照ください。  
https://imagingsolution.net/imaging/affine-transformation/

### （１）平行移動
アフィン変換を利用して画像をx方向に+30、y方向に-30だけ平行移動させてみましょう。  
平行移動の場合、アフィン変換の行列は、以下のようになります。

<img src="./pic/affine_parallel_1.JPG" width=70% style="float: left">  

平行移動前後の画像は以下の通りです。  
<img src="./pic/before_after_parallel.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
_img = cv2.imread("./pic/hinemos_monita.jpg")
```


```python
# 【回答】画像を平行移動させる関数（affine）を定義

def affine(img, a, b, c, d, tx, ty):

    H, W, C = img.shape

    # 元画像に両端1画素ずつ余白を作成
    img = np.zeros((H+2, W+2, C), dtype=np.float32)
    img[1:H+1, 1:W+1] = _img

    # アフィン変換後の画像の縦横サイズを取得
    H_new = np.round(H * d).astype(np.int)
    W_new = np.round(W * a).astype(np.int)
    
    # アフィン変換後の画像の枠を作成
    out = np.zeros((H_new+1, W_new+1, C), dtype=np.float32)

    # アフィン変換後の座標を取得
    x_new = np.tile(np.arange(W_new), (H_new, 1))
    y_new = np.arange(H_new).repeat(W_new).reshape(H_new, -1)

    # ★アフィン変換の逆操作（上記の【参考】の式を参照）
    adbc = a * d - b * c
    x = np.round((d * x_new  - b * y_new) / adbc).astype(np.int) - tx + 1
    y = np.round((-c * x_new + a * y_new) / adbc).astype(np.int) - ty + 1

    x = np.minimum(np.maximum(x, 0), W+1).astype(np.int)
    y = np.minimum(np.maximum(y, 0), H+1).astype(np.int)

    # アフィン変換後の座標に元画像のピクセルを当てはめる
    out[y_new, x_new] = img[y, x]

    out = out[:H_new, :W_new]
    out = out.astype(np.uint8)

    return out
```

【参考】  
元画像に対して１ピクセルずつ行うと、処理後の画像で値が割り当てられない可能性がでてきてしまいます。  
よって、処理後画像の各ピクセルに対してAffine変換の逆変換を行い、値を割り当てる元画像の座標を取得する必要があります。  
Affine変換の逆操作は、アフィン変換の行列の式の両辺に３×３の逆行列を掛け、  
変換前の座標(x, y)と変換後の座標(x’,y’)を逆にして、変換後の座標から変換前の座標を求めます。（上記コードの★が該当）    
<img src="./pic/affine_equ6.png" width=50%>  

より詳細な説明については、以下をご参照ください。  
https://qiita.com/koshian2/items/c133e2e10c261b8646bf


```python
# 【回答】affine()関数を用いて、x方向に+30、y方向に-30だけ平行移動した画像を表示せよ　
img = affine(_img,a=1, b=0, c=0, d=1, tx=30, ty=-30)
plt.imshow(img)
plt.show()
```


![png](output_62_0.png)


<br>

### （２）拡大縮小
アフィン変換を用いて、  
(1)x方向に1.3倍、y方向に0.8倍にリサイズしてみましょう。  
(2) (1)の条件に加えて、x方向に+30、y方向に-30だけ平行移動を同時に実行してみましょう。

拡大縮小の場合、アフィン変換の行列は以下のようにります。  
（X軸方向の拡大率：Sx、Y軸方向の拡大率：Sy）  
<img src="./pic/affine_scle_1.png" width=70%　style="float: left">

拡大前後の画像は以下の通りです。  
<img src="./pic/before_after_expansion.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
_img = cv2.imread("./pic/hinemos_monita.jpg")
```


```python
# 【回答】affine()関数を用いて、x方向に1.3倍、y方向に0.8倍にリサイズし、
# x方向に+30、y方向に-30だけ平行移動した画像を表示
out = affine(_img, a=1.3, b=0, c=0, d=0.8, tx=30, ty=-30)
plt.imshow(out)
plt.show()
```


![png](output_67_0.png)


<br>

### （３）回転
(1)アフィン変換を用いて、反時計方向に30度回転させてみましょう。  
(2)アフィン変換を用いて、反時計方向に30度回転した画像で中心座標を固定することで、  
　なるべく黒い領域がなくなるように画像を作成してみましょう。   
　（ただし、単純なアフィン変換を行うと画像が切れてしまうので、工夫を要します。）

アフィン変換において、原点を中心に反時計回りにθ°回転する時のアフィン変換は次式となります。

<img src="./pic/affine_role_1.png" width=70% style="float: left">

回転前後の画像は以下の通りです。  
<img src="./pic/before_after_role.png" width=40% style="float: left; margin: 0.1em 0.1em 0.1em 0;">


```python
# 画像の読み込み
_img = cv2.imread("./pic/hinemos_monita.jpg")
```


```python
# 【回答】画像を回転させる関数（affine）を定義

def affine(img, a, b, c, d, tx, ty):
    
    # 途中までは（1）、（2）と同様
    H, W, C = _img.shape

    # 元画像に両端1画素ずつ余白を作成
    img = np.zeros((H+2, W+2, C), dtype=np.float32)
    img[1:H+1, 1:W+1] = _img

    # アフィン変換後の画像の縦横サイズを取得
    H_new = np.round(H).astype(np.int)
    W_new = np.round(W).astype(np.int)
    
    # アフィン変換後の画像の枠を作成
    out = np.zeros((H_new, W_new, C), dtype=np.float32)

    # アフィン変換後の座標を取得
    x_new = np.tile(np.arange(W_new), (H_new, 1))
    y_new = np.arange(H_new).repeat(W_new).reshape(H_new, -1)

    # ★アフィン変換の逆操作（下記の【参考】の式を参照）
    adbc = a * d - b * c
    x = np.round((d * x_new  - b * y_new) / adbc).astype(np.int) - tx + 1
    y = np.round((-c * x_new + a * y_new) / adbc).astype(np.int) - ty + 1

    # ここまでは（1）、（2）と同様
    
    # アフィン変換で回転↓画像で中心座標を固定
    dcx = (x.max() + x.min()) // 2 - W // 2
    dcy = (y.max() + y.min()) // 2 - H // 2

    x -= dcx
    y -= dcy

    x = np.clip(x, 0, W + 1)
    y = np.clip(y, 0, H + 1)

    # assign pixcel
    out[y_new, x_new] = img[y, x]
    out = out.astype(np.uint8)

    return out
```


```python
# 画像を表示
A = 30.
theta = - np.pi * A / 180.
out = affine(_img, a=np.cos(theta), b=-np.sin(theta), c=np.sin(theta), d=np.cos(theta),tx=0, ty=0)

plt.imshow(out)
plt.show()
```


![png](output_74_0.png)


<br>
